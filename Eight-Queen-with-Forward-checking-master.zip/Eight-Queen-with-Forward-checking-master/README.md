# Eight-Queen-with-Forward-checking

In this program you can get source code of eight queen pazzle by using forward cheacking which is a part of Constrain Satisfation Problem.
Firtly it ask you where first queen you want to keep then auto adjust all queens by self.
